# Project guide: syllabus mapping

## Java / OOP concepts demonstrated

| Syllabus area | Where it appears |
|---|---|
| Classes, objects, constructors | `ChatServer`, `ClientHandler`, `ChatClient`, and `ChatMessage` |
| Encapsulation and access control | Private fields with public or package-private methods |
| Inheritance | `ChatClient extends JFrame` |
| Interfaces | `ClientHandler implements Runnable`; Swing event listeners are used for GUI actions |
| Threads and multithreading | A new `Thread` handles each server connection; another thread reads each client's incoming messages |
| Synchronization | Synchronized server client-list operations and synchronized writes to each client |
| Static/final members and constants | `DEFAULT_PORT`, message limits, and the immutable `ChatMessage` model |
| Generics and collections | `Set<ClientHandler>` and `List<ClientHandler>` |
| Packages and imports | `chatapp.client`, `chatapp.server`, and `chatapp.common` |
| Exception handling | `try`/`catch`/`finally` and try-with-resources for network resources |
| Strings and wrapper classes | String validation and `Integer.parseInt()` for the port |
| GUI and layout managers | Swing `JFrame`, `JTextArea`, `JTextField`, `BorderLayout`, and `FlowLayout` |

## Data Communication and Networking concepts demonstrated

| Syllabus area | Where it appears |
|---|---|
| Client-server architecture | `ChatClient` connects to `ChatServer` |
| Transport layer / TCP | `Socket` and `ServerSocket` provide reliable, ordered TCP streams |
| Connection setup and teardown | TCP connect, `/quit`, socket close, and disconnect messages |
| Application layer protocol | UTF-8, line-based protocol: first line is the username; later lines are chat messages |
| Host addressing and ports | Client host field and server port (default `5000`) |
| Multiple simultaneous connections | Each accepted socket gets its own handler thread |
| Basic message logging | `ChatLogger` appends chat events to `chat-history.log` |

TCP provides reliable byte delivery, so this application does not implement its own parity, checksum, CRC, Hamming code, or ARQ algorithm. Physical media, routing algorithms, IPv4/IPv6 internals, and the OSI layers are generally handled by the operating system/network rather than reimplemented in this app.

## Concepts not implemented in this version

This practical project does not force every topic into the chat application. Finalization hooks, native methods, cloning, applets, custom error-correction algorithms, and JDBC persistence are not needed for the core chat workflow. The current chat history uses a log file, not a database. JDBC/MySQL persistence can be added as a separate extension if your instructor specifically requires it.

## Suggested demonstration

1. Start `run-server.bat`.
2. Start two or three client windows with different usernames.
3. Send messages from each client and show that every connected client receives them.
4. Try duplicate usernames and show that the server assigns a unique name.
5. Disconnect one client and show the join/leave notices and `chat-history.log`.
6. For a networking demonstration, use the host computer's private IPv4 address from another computer on the same trusted LAN.
