@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -d out src\chatapp\common\*.java src\chatapp\server\*.java src\chatapp\client\*.java
if errorlevel 1 (
    echo Build failed. Check the Java compiler and the error messages above.
    exit /b 1
)
echo Build successful. Compiled classes are in the out folder.
endlocal
