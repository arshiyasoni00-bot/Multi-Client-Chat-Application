@echo off
call "%~dp0build.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
java -cp out chatapp.server.ChatServer 5000
