package chatapp.client;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Swing GUI client. Run multiple instances to chat with one another. */
public final class ChatClient extends JFrame {
    private final JTextField hostField = new JTextField("127.0.0.1", 12);
    private final JTextField portField = new JTextField("5000", 5);
    private final JTextField usernameField = new JTextField("Guest", 10);
    private final JButton connectButton = new JButton("Connect");

    private final JTextArea chatArea = new JTextArea();
    private final JTextField messageField = new JTextField();
    private final JButton sendButton = new JButton("Send");
    private final JButton disconnectButton = new JButton("Disconnect");

    private volatile boolean connected;
    private Socket socket;
    private BufferedReader input;
    private PrintWriter output;

    public ChatClient() {
        super("Multi-Client Chat Application");
        buildInterface();
        setControlsConnected(false);
        setSize(820, 560);
        setMinimumSize(new java.awt.Dimension(650, 400));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent event) {
                closeConnection(true, false);
                dispose();
            }
        });
    }

    private void buildInterface() {
        JPanel connectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        connectionPanel.setBorder(BorderFactory.createTitledBorder("Connection settings"));
        connectionPanel.add(new JLabel("Server host:"));
        connectionPanel.add(hostField);
        connectionPanel.add(new JLabel("Port:"));
        connectionPanel.add(portField);
        connectionPanel.add(new JLabel("Username:"));
        connectionPanel.add(usernameField);
        connectionPanel.add(connectButton);

        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        chatArea.setText("Welcome! Start the server, enter your details, and click Connect.\n");
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Chat messages"));

        JPanel messagePanel = new JPanel(new BorderLayout(8, 0));
        messagePanel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        messagePanel.add(messageField, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        buttons.add(sendButton);
        buttons.add(disconnectButton);
        messagePanel.add(buttons, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(8, 8));
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        content.add(connectionPanel, BorderLayout.NORTH);
        content.add(scrollPane, BorderLayout.CENTER);
        content.add(messagePanel, BorderLayout.SOUTH);
        setContentPane(content);

        connectButton.addActionListener(event -> connectToServer());
        sendButton.addActionListener(event -> sendMessage());
        messageField.addActionListener(event -> sendMessage());
        disconnectButton.addActionListener(event -> closeConnection(true, true));
    }

    private void connectToServer() {
        if (connected) {
            return;
        }

        String host = hostField.getText().trim();
        String username = usernameField.getText().trim();
        if (host.isEmpty() || username.isEmpty()) {
            showError("Enter a server host and username.");
            return;
        }

        final int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1 || port > 65535) {
                throw new NumberFormatException("Port out of range");
            }
        } catch (NumberFormatException exception) {
            showError("Port must be a number between 1 and 65535.");
            return;
        }

        try {
            Socket newSocket = new Socket();
            newSocket.connect(new InetSocketAddress(host, port), 5000);
            BufferedReader newInput = new BufferedReader(
                    new InputStreamReader(newSocket.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter newOutput = new PrintWriter(
                    new OutputStreamWriter(newSocket.getOutputStream(), StandardCharsets.UTF_8), true);
            newOutput.println(username);

            socket = newSocket;
            input = newInput;
            output = newOutput;
            connected = true;
            setControlsConnected(true);
            appendMessage("[SYSTEM] Connected to " + host + ":" + port + ".");
            messageField.requestFocusInWindow();

            Thread readerThread = new Thread(
                    () -> readMessages(newSocket, newInput),
                    "chat-reader-" + username);
            readerThread.setDaemon(true);
            readerThread.start();
        } catch (IOException exception) {
            showError("Could not connect: " + exception.getMessage());
        }
    }

    private void readMessages(Socket activeSocket, BufferedReader activeInput) {
        try {
            String line;
            while ((line = activeInput.readLine()) != null) {
                String message = line;
                SwingUtilities.invokeLater(() -> appendMessage(message));
            }
        } catch (IOException exception) {
            if (!activeSocket.isClosed()) {
                SwingUtilities.invokeLater(() -> appendMessage("[SYSTEM] Connection ended: " + exception.getMessage()));
            }
        } finally {
            SwingUtilities.invokeLater(() -> {
                if (socket == activeSocket) {
                    closeConnection(false, true);
                }
            });
        }
    }

    private void sendMessage() {
        if (!connected || output == null) {
            return;
        }
        String message = messageField.getText();
        if (message == null || message.isBlank()) {
            return;
        }
        output.println(message);
        messageField.setText("");
        if (message.trim().equalsIgnoreCase("/quit")) {
            closeConnection(false, true);
        }
    }

    private void closeConnection(boolean sendQuit, boolean showStatus) {
        PrintWriter activeOutput = output;
        Socket activeSocket = socket;
        connected = false;
        output = null;
        input = null;
        socket = null;

        if (sendQuit && activeOutput != null) {
            activeOutput.println("/quit");
        }
        if (activeSocket != null) {
            try {
                activeSocket.close();
            } catch (IOException ignored) {
                // The connection may already be closed.
            }
        }
        setControlsConnected(false);
        if (showStatus) {
            appendMessage("[SYSTEM] Disconnected.");
        }
    }

    private void setControlsConnected(boolean isConnected) {
        connectButton.setEnabled(!isConnected);
        hostField.setEnabled(!isConnected);
        portField.setEnabled(!isConnected);
        usernameField.setEnabled(!isConnected);
        messageField.setEnabled(isConnected);
        sendButton.setEnabled(isConnected);
        disconnectButton.setEnabled(isConnected);
    }

    private void appendMessage(String message) {
        chatArea.append(message + System.lineSeparator());
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Chat application", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatClient().setVisible(true));
    }
}
