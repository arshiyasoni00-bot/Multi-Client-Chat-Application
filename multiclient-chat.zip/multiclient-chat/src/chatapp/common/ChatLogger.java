package chatapp.common;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Writes server chat events to chat-history.log without requiring an external library. */
public final class ChatLogger {
    private static final Path LOG_FILE = Path.of("chat-history.log");
    private static final DateTimeFormatter LOG_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private ChatLogger() {
        // Utility class; do not instantiate.
    }

    public static synchronized void log(String message) {
        String safeMessage = message.replace('\r', ' ').replace('\n', ' ');
        String entry = LocalDateTime.now().format(LOG_TIME) + " " + safeMessage + System.lineSeparator();
        try {
            Files.writeString(
                    LOG_FILE,
                    entry,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE,
                    StandardOpenOption.APPEND);
        } catch (IOException exception) {
            System.err.println("Could not write chat log: " + exception.getMessage());
        }
    }
}
