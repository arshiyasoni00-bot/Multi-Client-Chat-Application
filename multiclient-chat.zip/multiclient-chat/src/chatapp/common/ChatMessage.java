package chatapp.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/** Immutable model representing one chat message. */
public final class ChatMessage {
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final String sender;
    private final String text;
    private final LocalDateTime sentAt;

    public ChatMessage(String sender, String text) {
        this(sender, text, LocalDateTime.now());
    }

    public ChatMessage(String sender, String text, LocalDateTime sentAt) {
        this.sender = Objects.requireNonNull(sender, "sender");
        this.text = Objects.requireNonNull(text, "text");
        this.sentAt = Objects.requireNonNull(sentAt, "sentAt");
    }

    public String getSender() {
        return sender;
    }

    public String getText() {
        return text;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public String formatForChat() {
        return "[" + sentAt.format(TIME_FORMAT) + "] " + sender + ": " + text;
    }
}
