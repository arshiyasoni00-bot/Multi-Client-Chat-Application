package chatapp.server;

import chatapp.common.ChatLogger;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** TCP chat server that broadcasts messages to every connected client. */
public final class ChatServer {
    public static final int DEFAULT_PORT = 5000;

    private final Set<ClientHandler> clients = new HashSet<>();
    private volatile boolean running;
    private ServerSocket serverSocket;

    public ChatServer() {
        this(DEFAULT_PORT);
    }

    public ChatServer(int port) {
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port must be between 1 and 65535.");
        }
        this.port = port;
    }

    private final int port;

    public void start() {
        running = true;
        try (ServerSocket listeningSocket = new ServerSocket(port)) {
            serverSocket = listeningSocket;
            System.out.println("=======================================");
            System.out.println(" Multi-Client Chat Server");
            System.out.println(" Listening on port " + port);
            System.out.println(" Press Ctrl+C to stop the server.");
            System.out.println("=======================================");

            while (running) {
                try {
                    Socket clientSocket = listeningSocket.accept();
                    System.out.println("Client connected: " + clientSocket.getRemoteSocketAddress());
                    ClientHandler handler = new ClientHandler(this, clientSocket);
                    Thread clientThread = new Thread(
                            handler,
                            "chat-client-" + clientSocket.getPort());
                    clientThread.start();
                } catch (SocketException exception) {
                    if (running) {
                        System.err.println("Socket error: " + exception.getMessage());
                    }
                    break;
                }
            }
        } catch (IOException exception) {
            if (running) {
                System.err.println("Could not start server: " + exception.getMessage());
                System.err.println("Check whether another program is using port " + port + ".");
            }
        } finally {
            running = false;
            serverSocket = null;
            for (ClientHandler client : getClientSnapshot()) {
                client.disconnect();
            }
            System.out.println("Chat server stopped.");
        }
    }

    /** Adds a client and makes the username unique among currently connected clients. */
    synchronized String registerClient(ClientHandler client, String requestedName, int maxLength) {
        String baseName = cleanUsername(requestedName, maxLength);
        String candidate = baseName;
        int suffix = 2;
        while (usernameExists(candidate)) {
            String suffixText = Integer.toString(suffix++);
            int prefixLength = Math.max(1, maxLength - suffixText.length());
            String prefix = baseName.substring(0, Math.min(baseName.length(), prefixLength));
            candidate = prefix + suffixText;
        }
        client.setUsername(candidate);
        clients.add(client);
        System.out.println(candidate + " joined. Active clients: " + clients.size());
        return candidate;
    }

    private String cleanUsername(String requestedName, int maxLength) {
        String cleaned = requestedName == null ? "" : requestedName.trim();
        cleaned = cleaned.replaceAll("[\\r\\n\\t]", " ")
                         .replaceAll("[^\\p{L}\\p{N}_ -]", "")
                         .trim();
        if (cleaned.isBlank()) {
            cleaned = "Guest";
        }
        if (cleaned.length() > maxLength) {
            cleaned = cleaned.substring(0, maxLength);
        }
        return cleaned;
    }

    private boolean usernameExists(String candidate) {
        for (ClientHandler client : clients) {
            if (client.getUsername().equalsIgnoreCase(candidate)) {
                return true;
            }
        }
        return false;
    }

    public void broadcast(String message) {
        System.out.println(message);
        ChatLogger.log(message);
        for (ClientHandler client : getClientSnapshot()) {
            client.send(message);
        }
    }

    synchronized boolean removeClient(ClientHandler client) {
        boolean removed = clients.remove(client);
        if (removed) {
            System.out.println(client.getUsername() + " disconnected. Active clients: " + clients.size());
        }
        return removed;
    }

    private synchronized List<ClientHandler> getClientSnapshot() {
        return new ArrayList<>(clients);
    }

    public void stop() {
        running = false;
        ServerSocket activeServerSocket = serverSocket;
        if (activeServerSocket != null) {
            try {
                activeServerSocket.close();
            } catch (IOException ignored) {
                // The server socket may already be closed.
            }
        }
        for (ClientHandler client : getClientSnapshot()) {
            client.disconnect();
        }
    }

    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException exception) {
                System.err.println("Usage: java chatapp.server.ChatServer [port]");
                return;
            }
        }

        ChatServer server;
        try {
            server = new ChatServer(port);
        } catch (IllegalArgumentException exception) {
            System.err.println(exception.getMessage());
            return;
        }
        Runtime.getRuntime().addShutdownHook(new Thread(server::stop, "chat-server-shutdown"));
        server.start();
    }
}
