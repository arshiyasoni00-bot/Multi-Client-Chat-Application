package chatapp.server;

import chatapp.common.ChatMessage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Handles one connected user. Each instance runs on its own thread. */
public final class ClientHandler implements Runnable {
    private static final int MAX_MESSAGE_LENGTH = 2000;
    private static final int MAX_USERNAME_LENGTH = 20;

    private final ChatServer server;
    private final Socket clientSocket;
    private final Object writeLock = new Object();

    private volatile PrintWriter output;
    private volatile String username = "";

    public ClientHandler(ChatServer server, Socket clientSocket) {
        this.server = server;
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        boolean joined = false;
        try (Socket ignored = clientSocket;
             BufferedReader input = new BufferedReader(
                     new InputStreamReader(clientSocket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter writer = new PrintWriter(
                     new OutputStreamWriter(clientSocket.getOutputStream(), StandardCharsets.UTF_8), true)) {

            synchronized (writeLock) {
                output = writer;
            }

            String requestedUsername = input.readLine();
            if (requestedUsername == null) {
                return;
            }

            username = server.registerClient(this, requestedUsername, MAX_USERNAME_LENGTH);
            joined = true;
            send("[SYSTEM] Connected as " + username + ". Type /quit to leave the chat.");
            server.broadcast("[SYSTEM] " + username + " joined the chat.");

            String line;
            while ((line = input.readLine()) != null) {
                if (line.trim().equalsIgnoreCase("/quit")) {
                    break;
                }
                if (line.isBlank()) {
                    continue;
                }
                if (line.length() > MAX_MESSAGE_LENGTH) {
                    send("[SYSTEM] Message too long. Limit: " + MAX_MESSAGE_LENGTH + " characters.");
                    continue;
                }

                ChatMessage message = new ChatMessage(username, line);
                server.broadcast(message.formatForChat());
            }
        } catch (IOException exception) {
            if (!clientSocket.isClosed()) {
                System.err.println("Connection issue for " + safeUsername() + ": " + exception.getMessage());
            }
        } finally {
            synchronized (writeLock) {
                output = null;
            }
            if (server.removeClient(this) && joined) {
                server.broadcast("[SYSTEM] " + username + " left the chat.");
            }
        }
    }

    public String getUsername() {
        return username;
    }

    void setUsername(String username) {
        this.username = username;
    }

    public void send(String message) {
        synchronized (writeLock) {
            PrintWriter writer = output;
            if (writer != null) {
                writer.println(message);
            }
        }
    }

    public void disconnect() {
        try {
            clientSocket.close();
        } catch (IOException ignored) {
            // The socket may already be closed.
        }
    }

    private String safeUsername() {
        return username.isBlank() ? "new client" : username;
    }
}
